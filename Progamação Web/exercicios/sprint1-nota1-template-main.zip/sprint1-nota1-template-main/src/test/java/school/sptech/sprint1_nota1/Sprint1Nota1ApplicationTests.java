package school.sptech.sprint1_nota1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint1Nota1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
