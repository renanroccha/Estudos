package school.sptech;

import java.util.Scanner;

public class DesafioScanner {

  public static void main(String[] args) {

    // Cadastro de PET
    // Peça para o usuário digitar:
    // - Nome
    // - Altura
    // - Idade
    // Exiba as informações de forma "caprichada"

    Scanner leitor = new Scanner(System.in);

    System.out.println("Digite o nome do PET:");
    String nome = leitor.nextLine();

    System.out.println("Digite a altura do PET:");
    Double altura = leitor.nextDouble();

    System.out.println("Digite a idade do PET:");
    Integer idade = leitor.nextInt();

    System.out.println(String.format("""
        ---------------------------
         Ficha do Pet
        ---------------------------
         Nome: %s
         Altura: %.2f
         Idade: %d
        ---------------------------
        """, nome, altura, idade));
  }
}
