package school.sptech;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ExemploLista {

  public static void main(String[] args) {

    // Lista sem tipo definido

    List listaMaluca = new ArrayList();
    listaMaluca.add("Manoel Gomes");
    listaMaluca.add(8);
    listaMaluca.add(true);
    listaMaluca.add(1.75);

    System.out.println(listaMaluca);

    listaMaluca.add(0, "Diego");

    System.out.println(listaMaluca);

    listaMaluca.set(1, "Manoel Almeida");

    System.out.println(listaMaluca);

    Integer valor = 8;
    // int valor = 8; // Irá causar um erro, porque o método .remove irá tentar remover o valor pelo índice

    listaMaluca.remove(valor);

    System.out.println(listaMaluca);

    System.out.println("Primeira posição:");
    System.out.println(listaMaluca.get(0));

    // Lista com tipo definido

    List<Integer> listaNumeros = new ArrayList<>();
    listaNumeros.add(8);
    listaNumeros.add(50);
    listaNumeros.add(10);
    listaNumeros.add(2);

    System.out.println(listaNumeros);

    System.out.println("Tamanho da lista:");
    System.out.println(listaNumeros.size());

    // Lista com valores digitados pelo usuário

    List<Integer> listaDigitada = new ArrayList<>();

    for (int i = 0; i < listaDigitada.size(); i++) {
      System.out.println(listaDigitada.get(i));
    }

    Scanner leitor = new Scanner(System.in);

    System.out.println("Quantos valores deseja digitar?");
    Integer qtdValores = leitor.nextInt();

    for (int i = 0; i < qtdValores; i++) {
      System.out.println(
          String.format("Informe o %d° valor:", i + 1));
      Integer valorDigitado = leitor.nextInt();
      listaDigitada.add(valorDigitado);
    }

    System.out.println(listaDigitada);
  }
}
